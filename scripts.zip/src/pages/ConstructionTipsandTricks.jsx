import React, { Suspense, useState, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { Row } from 'reactstrap';
import Banner from "../common/Banner";
import NavBar from "../common/NavBar";
import useSeoHelmet from '../hooks/ReactHelmet';
import SeoHelmet from '../common/SeoHelmet';
import { useCustomQuery } from '../utils/QueryHooks';
import BlogServices from '../services/BlogServices';
import { buildQueryString } from '../utils/BuildQuery';
import Loader from '../utils/Loader/Loader';
import NoDataFound from '../utils/NoDataFound';
import BlogCard from '../components/blogandnews/BlogCard';
import Pagination from '../utils/Pagination';
import Footer from '../common/Footer';
import ScrollToTop from "../common/ScrollToTop";

// Constants
const BANNER_TITLE = "Blog and News";
const BANNER_DESCRIPTION = "Construction Tips & Tricks";
const CATEGORY_SLUG = "construction-tips-tricks";
const DEFAULT_LIMIT = 10;
const DEFAULT_PAGE = 1;
const LOADING_TEXT = "Loading...";

// Lazy-loaded components with error handling

// Loading component
const LoadingSpinner = ({ message = LOADING_TEXT }) => (
  <div className="flex items-center justify-center py-8">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mr-3"></div>
    <span className="text-gray-600">{message}</span>
  </div>
);

const ConstructionTipsandTricks = () => {
  const seo = useSeoHelmet("construction-tips-tricks");
  const location = useLocation();
  const searchParams = useMemo(() => new URLSearchParams(location.search), [location.search]);
  const [limit] = useState(DEFAULT_LIMIT);

  // Memoized current page
  const currentPage = useMemo(() =>
    parseInt(searchParams.get('page') || String(DEFAULT_PAGE)),
    [searchParams]
  );

  // Memoized query parameters
  const queryParams = useMemo(() =>
    buildQueryString([
      { key: "page", value: currentPage },
      { key: "limit", value: limit },
      { key: "category_slug", value: CATEGORY_SLUG },
      { key: "is_published", value: true }
    ]),
    [currentPage, limit]
  );

  // Fetch blog data
  const {
    data: blogList,
    isLoading: isBlogLoad,
  } = useCustomQuery({
    queryKey: ['blog-list-category', currentPage, limit],
    service: BlogServices.blogList,
    params: queryParams,
    select: (data) => data?.data,
    onSuccess: () => {
      // Optional: Analytics or other side effects
    }
  });

  return (
    <div>
      <SeoHelmet seo={seo} />
      <NavBar />
      <Banner title={BANNER_TITLE} description={BANNER_DESCRIPTION} />

      {isBlogLoad ? (
        <Loader />
      ) : (
        <section className="blog-listing common-section container">
          <Row>
            {blogList?.data?.length === 0 ? (
              <NoDataFound msg="No Blog Found" />
            ) : (
              blogList?.data.map(blog => (
                <BlogCard key={blog.id} blog={blog} />
              ))
            )}
          </Row>
          {!isBlogLoad && blogList?.pagination && (
            <Pagination pagination={blogList.pagination} />
          )}
        </section>
      )}

      <Suspense fallback={<LoadingSpinner message="Loading footer..." />}>
        <Footer />
      </Suspense>
      {/* Scroll to Top Button */}
      <ScrollToTop />
    </div>
  );
};

export default ConstructionTipsandTricks;
