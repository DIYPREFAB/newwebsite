import React from "react";
import { Link } from "react-router-dom";
import { FIGURES } from "./Figures";
import { parseInline } from "./utils";

export const Inline = ({ text }) =>
  parseInline(text).map((p, i) => {
    if (p.type === "bold") return <strong key={i}>{p.value}</strong>;
    if (p.type === "cite")
      return (
        <sup key={i} className="bt-cite">
          <a href={`#source-${p.value}`}>[{p.value}]</a>
        </sup>
      );
    if (p.type === "link")
      return p.href.startsWith("/") ? (
        <Link key={i} to={p.href}>{p.value}</Link>
      ) : (
        <a key={i} href={p.href} target="_blank" rel="noopener noreferrer">{p.value}</a>
      );
    return <React.Fragment key={i}>{p.value}</React.Fragment>;
  });

const ArticleBody = ({ blocks }) => (
  <div className="bt-prose">
    {blocks.map((b, i) => {
      switch (b.t) {
        case "h2":
          return <h2 key={i} id={b.id}>{b.text}</h2>;
        case "p":
          return <p key={i}><Inline text={b.text} /></p>;
        case "ul":
          return (
            <ul key={i}>
              {b.items.map((it, j) => <li key={j}><Inline text={it} /></li>)}
            </ul>
          );
        case "note":
          return (
            <aside key={i} className="bt-note">
              <strong>{b.title}</strong>
              <p><Inline text={b.text} /></p>
            </aside>
          );
        case "example":
          return (
            <aside key={i} className="bt-example">
              <strong>{b.title}</strong>
              <dl>
                {b.rows.map(([k, v]) => (
                  <React.Fragment key={k}>
                    <dt>{k}</dt>
                    <dd>{v}</dd>
                  </React.Fragment>
                ))}
              </dl>
            </aside>
          );
        case "figure": {
          const Fig = FIGURES[b.id];
          return Fig ? <Fig key={i} /> : null;
        }
        default:
          return null;
      }
    })}
  </div>
);

export default ArticleBody;
