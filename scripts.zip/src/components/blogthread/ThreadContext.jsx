import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { signInWithGoogle } from "./authService";
import AuthModal from "./AuthModal";
import { uid } from "./utils";
import { IconCheck } from "./icons";

// All thread data (user, reactions, comments) lives in this browser's localStorage for now.
// The functions on the context are the seam for the backend: swap their bodies for API calls later.
const USER_KEY = "dpf_thread_user_v1";
const DATA_KEY = "dpf_thread_data_v1";

const ThreadCtx = createContext(null);
export const useThread = () => useContext(ThreadCtx);

const read = (key, fallback) => {
  try {
    const v = JSON.parse(localStorage.getItem(key));
    return v ?? fallback;
  } catch {
    return fallback;
  }
};
const write = (key, value) => {
  try {
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable (private mode): the session still works in memory */
  }
};

export const REACTIONS = [
  { key: "useful", label: "Useful" },
  { key: "insightful", label: "Insightful" },
  { key: "sourced", label: "Well sourced" },
];

export const ThreadProvider = ({ children }) => {
  const [user, setUser] = useState(() => read(USER_KEY, null));
  const [data, setData] = useState(() => read(DATA_KEY, { reactions: {}, comments: {} }));
  const [auth, setAuth] = useState({ open: false, reason: "generic", busy: false, error: "" });
  const [toasts, setToasts] = useState([]);
  const pending = useRef(null);

  useEffect(() => write(DATA_KEY, data), [data]);
  useEffect(() => write(USER_KEY, user), [user]);

  const toast = useCallback((message) => {
    const id = uid();
    setToasts((t) => [...t, { id, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2600);
  }, []);

  /* ---------- auth ---------- */
  const openAuth = useCallback((reason = "generic", then = null) => {
    pending.current = then;
    setAuth({ open: true, reason, busy: false, error: "" });
  }, []);
  const closeAuth = useCallback(() => {
    pending.current = null;
    setAuth((a) => ({ ...a, open: false, busy: false, error: "" }));
  }, []);

  const requireAuth = useCallback(
    (reason, action) => {
      if (user) return action(user);
      openAuth(reason, action);
      return undefined;
    },
    [user, openAuth]
  );

  const signIn = useCallback(async () => {
    setAuth((a) => ({ ...a, busy: true, error: "" }));
    try {
      const u = await signInWithGoogle();
      setUser(u);
      const then = pending.current;
      pending.current = null;
      setAuth({ open: false, reason: "generic", busy: false, error: "" });
      toast(u.provider === "demo" ? "Signed in (preview mode)" : `Signed in as ${u.name}`);
      if (then) setTimeout(() => then(u), 280);
    } catch (e) {
      setAuth((a) => ({ ...a, busy: false, error: e.message || "Sign-in failed. Please try again." }));
    }
  }, [toast]);

  const signOut = useCallback(() => {
    setUser(null);
    toast("Signed out");
  }, [toast]);

  /* ---------- reactions ---------- */
  const reactionCounts = useCallback(
    (postId) => {
      const counts = { useful: 0, insightful: 0, sourced: 0 };
      Object.values(data.reactions[postId] || {}).forEach((k) => {
        if (counts[k] !== undefined) counts[k] += 1;
      });
      return counts;
    },
    [data.reactions]
  );
  const myReaction = useCallback((postId) => (user ? (data.reactions[postId] || {})[user.id] || null : null), [data.reactions, user]);

  const toggleReaction = useCallback((postId, key, u) => {
    setData((d) => {
      const forPost = { ...(d.reactions[postId] || {}) };
      if (forPost[u.id] === key) delete forPost[u.id];
      else forPost[u.id] = key;
      return { ...d, reactions: { ...d.reactions, [postId]: forPost } };
    });
  }, []);

  /* ---------- comments ---------- */
  const commentsFor = useCallback((postId) => data.comments[postId] || [], [data.comments]);

  const addComment = useCallback(
    (postId, text, parentId, u) => {
      const c = {
        id: uid(),
        parentId: parentId || null,
        userId: u.id,
        name: u.name,
        picture: u.picture || "",
        text: text.trim(),
        createdAt: new Date().toISOString(),
        likes: [],
      };
      setData((d) => ({ ...d, comments: { ...d.comments, [postId]: [...(d.comments[postId] || []), c] } }));
      return c.id;
    },
    []
  );

  const toggleCommentLike = useCallback((postId, commentId, u) => {
    setData((d) => ({
      ...d,
      comments: {
        ...d.comments,
        [postId]: (d.comments[postId] || []).map((c) =>
          c.id !== commentId ? c : { ...c, likes: c.likes.includes(u.id) ? c.likes.filter((x) => x !== u.id) : [...c.likes, u.id] }
        ),
      },
    }));
  }, []);

  const deleteComment = useCallback((postId, commentId) => {
    setData((d) => {
      const list = d.comments[postId] || [];
      const gone = new Set([commentId]);
      let grew = true;
      while (grew) {
        grew = false;
        list.forEach((c) => {
          if (c.parentId && gone.has(c.parentId) && !gone.has(c.id)) {
            gone.add(c.id);
            grew = true;
          }
        });
      }
      return { ...d, comments: { ...d.comments, [postId]: list.filter((c) => !gone.has(c.id)) } };
    });
    toast("Comment deleted");
  }, [toast]);

  const value = useMemo(
    () => ({ user, requireAuth, openAuth, signOut, reactionCounts, myReaction, toggleReaction, commentsFor, addComment, toggleCommentLike, deleteComment, toast }),
    [user, requireAuth, openAuth, signOut, reactionCounts, myReaction, toggleReaction, commentsFor, addComment, toggleCommentLike, deleteComment, toast]
  );

  return (
    <ThreadCtx.Provider value={value}>
      <MotionConfig reducedMotion="user">
        {children}
        <AuthModal state={auth} onClose={closeAuth} onGoogle={signIn} />
        <div className="bt-toasts" role="status" aria-live="polite">
          <AnimatePresence>
            {toasts.map((t) => (
              <motion.div
                key={t.id}
                className="bt-toast"
                initial={{ opacity: 0, y: 16, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.97 }}
                transition={{ type: "spring", stiffness: 420, damping: 32 }}
              >
                <IconCheck width={16} height={16} /> {t.message}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </MotionConfig>
    </ThreadCtx.Provider>
  );
};
